package com.example.currencyconverter;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    public double[] b;
    public double r,result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Spinner s1=findViewById(R.id.spinner);
        Spinner s2=findViewById(R.id.spinner2);
        Button b1=findViewById(R.id.button);
        TextView f=findViewById(R.id.textView6);
        EditText amt=findViewById(R.id.editTextNumberDecimal);
        String[] base={"America","China","Australia","Canada"};
        ArrayAdapter<String> a1= new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,base);
        String[] res={"India","Sri Lanka","PhilliePines","Pakistan"};
        ArrayAdapter<String> a2= new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,res);
        s1.setAdapter(a1);
        s2.setAdapter(a2);
        s1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i) {
                    case 0:
                        b= new double[]{79.53D, 359.64D, 56.30D, 207.21D};
                        break;
                    case 1:
                        b = new double[]{11.83D,53.48D,8.37D,30.81D};
                        break;
                    case 2:
                        b= new double[]{53.86D,243.43D,38.13D,140.26D};
                        break;
                    case 3:
                        b= new double[]{61.16D,276.44D,43.30D,159.28D};
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        s2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i) {
                    case 0:
                        r=b[0];
                        break;
                    case 1:
                        r=b[1];
                        break;
                    case 2:
                        r=b[2];
                        break;
                    case 3:
                        r=b[3];
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        b1.setOnClickListener((View v) -> {
            if(amt.getText().toString().equals("")) {
                result=1.00D;
            }
            else {
                result = Double.parseDouble(amt.getText().toString());
            }
            result*=r;
            String j=String.valueOf(result);
            f.setText(j);
        });
    }
}